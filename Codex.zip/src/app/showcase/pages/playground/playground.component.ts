import { Component } from '@angular/core';

@Component({
    templateUrl: './playground.component.html'
})
export class PlaygroundComponent {}
