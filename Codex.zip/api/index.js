import { app } from '../dist/primeng/server/server.mjs';

const server = app();

export default server;
