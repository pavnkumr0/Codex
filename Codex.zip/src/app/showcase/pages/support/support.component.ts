import { Component } from '@angular/core';

@Component({
    templateUrl: './support.component.html'
})
export class SupportComponent {}
