/**
 * Type of the confirm event.
 */
export enum ConfirmEventType {
    ACCEPT,
    REJECT,
    CANCEL
}
