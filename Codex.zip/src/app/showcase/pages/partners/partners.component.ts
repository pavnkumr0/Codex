import { Component } from '@angular/core';

@Component({
    selector: 'partners',
    templateUrl: './partners.component.html'
})
export class PartnersComponent {}
