export const environment = {
    production: true,
    apiUrl: 'https://www.primefaces.org/data/customers'
};
