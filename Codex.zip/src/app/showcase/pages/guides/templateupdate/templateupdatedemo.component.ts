import { Component } from '@angular/core';

@Component({
    selector: 'template-update',
    templateUrl: './templateupdatedemo.component.html'
})
export class TemplateUpdateDemoComponent {
    docs = [];
}
